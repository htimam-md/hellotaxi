# 90 Day Fiancé: It's an illusion

A Pen created on CodePen.io. Original URL: [https://codepen.io/jackiezen/pen/gOryEyW](https://codepen.io/jackiezen/pen/gOryEyW).

The best Jesse quote from 90 Day Fiancé.

Based on illustration from Serif Supply 
https://www.serifsupply.com/shop/its-an-illusion