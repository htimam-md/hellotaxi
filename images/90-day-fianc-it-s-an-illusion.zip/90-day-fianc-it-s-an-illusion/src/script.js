$(function () {
	$("h1").lettering();
	$("h2").lettering();
});


// INSPIRED BY ILLUSTRATION FROM SERIF SUPPLY
// https://www.serifsupply.com/shop/its-an-illusion
